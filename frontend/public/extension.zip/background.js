// background.js — Service worker: message hub between content scripts and backend

// Tabs the extension itself opened for background work (scraping, connecting,
// applying), keyed by a purpose string (e.g. a source name or "linkedin_connect").
// We ONLY ever reuse a tab through this map — never chrome.tabs.query() for
// "any tab matching this host that isn't currently focused", because that
// would just as happily grab a tab the USER opened to read a profile or
// browse a job themselves (perfectly capable of being "not active" while they
// look at a different tab) and hijack it out from under them.
const _workerTabIds = {};

async function getOrCreateWorkerTab(key, url) {
  const existingId = _workerTabIds[key];
  if (existingId != null) {
    try {
      const tab = await chrome.tabs.get(existingId);
      if (tab) {
        await chrome.tabs.update(existingId, { url });
        return tab;
      }
    } catch {
      // Tab was closed or no longer exists — fall through and create a new one.
    }
  }
  const tab = await chrome.tabs.create({ url, active: false });
  _workerTabIds[key] = tab.id;
  return tab;
}

// MUST match the deployed LinkedIn API URL (and popup.js / manifest.json).
const BACKEND = (typeof __BACKEND_URL__ !== "undefined") ? __BACKEND_URL__ : "https://jobhuntpro-linkedin-api.onrender.com";
const DEFAULT_DAILY_LIMIT = 14; // Conservative daily cap inferred from the common ~100 invitations/week restriction.
const MIN_DAILY_LIMIT = 1;
const MAX_DAILY_LIMIT = 100;
const SESSION_ACTIVE_KEY = "jh_session_active";
const SCRAPE_SOURCES = {
  linkedin: {
    // A single boolean-OR query under-returns compared to running each role
    // separately — LinkedIn's own search seems to cap/dilute results for
    // longer OR chains. So instead of one query, we run several SEPARATE
    // searches back-to-back in the same tab (see LINKEDIN_KEYWORD_QUERIES /
    // runScrapeTask's linkedin branch below), each a real, undiluted result
    // page. f_TPR=r86400 → past 24h · f_E=1,2,3 → Internship/Entry/Associate
    // only (no Mid-Senior/Director/Exec) · f_JT=F,I → Full-time + Internship
    // only (excludes Contract/Part-time/Temp) · geoId=102713980 → India ·
    // sortBy=DD → newest first, so the truly-fresh (minutes-old) postings are
    // always at the top of each search.
    urls: null, // computed below, once LINKEDIN_KEYWORD_QUERIES is declared
    hostPrefix: "https://www.linkedin.com/",
    injectFile: "content/linkedin_jobs.js",
  },
  naukri: {
    url: "https://www.naukri.com/software-engineer-jobs",
    hostPrefix: "https://www.naukri.com/",
    injectFile: "content/naukri.js",
  },
  cutshort: {
    url: "https://cutshort.io/jobs",
    hostPrefix: "https://cutshort.io/",
    injectFile: "content/cutshort.js",
  },
  instahyre: {
    // Instahyre's Angular app does NOT read search filters (years, job_functions,
    // company_size, ...) from the query string on load — those only apply when
    // the sidebar form is submitted client-side. A direct URL with those params
    // just lands on the default recommended/matching feed and ignores them
    // (confirmed: it showed "No matching opportunities found"). So we use the
    // plain recommended feed and rely on the card + in-modal experience gate
    // (job_match.js / instahyre.js) to drop anything wanting >1 year.
    url: "https://www.instahyre.com/candidate/opportunities/",
    hostPrefix: "https://www.instahyre.com/",
    injectFile: "content/instahyre.js",
  },
  hiringcafe: {
    // Targeted at the SOURCE: searchQuery "Software Engineer" + the 4 tech
    // departments + roleYoeRange [0,1] (junior) + sortBy date. The scraper then
    // only trims to the last 24h. Location = India via IP geo. SSR embeds jobs in
    // __NEXT_DATA__.
    url: "https://hiring.cafe/?searchState=%7B%22searchQuery%22%3A%22Software+Engineer%22%2C%22dateFetchedPastNDays%22%3A2%2C%22departments%22%3A%5B%22Software+Development%22%2C%22Engineering%22%2C%22Information+Technology%22%2C%22Data+and+Analytics%22%5D%2C%22roleYoeRange%22%3A%5B0%2C1%5D%2C%22sortBy%22%3A%22date%22%7D",
    hostPrefix: "https://hiring.cafe/",
    injectFile: "content/hiringcafe.js",
  },
  wellfound: {
    // User's saved Wellfound profile filters apply automatically when logged in:
    // Software Engineer · Bengaluru · 0-1 years experience · sorted by Most Recent.
    url: "https://wellfound.com/jobs",
    hostPrefix: "https://wellfound.com/",
    injectFile: "content/wellfound.js",
  },
  indeed: {
    // Same multi-keyword iteration as LinkedIn, same reason: one combined
    // query under-returns vs. running each title separately. fromage=1 → past
    // 24h · explvl=entry_level → entry-level classification · jt=fulltime →
    // full-time only · sort=date → newest first. in.indeed.com specifically
    // (indeed.com alone redirects to the US site and ignores l=India).
    urls: null, // computed below, once INDEED_KEYWORD_QUERIES is declared
    hostPrefix: "https://in.indeed.com/",
    injectFile: "content/indeed.js",
  },
  apna: {
    // Apna's "Date posted" filter is pure client-side React state — the URL
    // never changes when you apply it (confirmed) — so there's no way to
    // deep-link into a filtered search. The content script drives the "Last
    // 24 hours" radio itself after load. Only two category slugs confirmed to
    // actually scope results server-side (most guessed slugs silently fall
    // back to the entire unfiltered job feed instead of erroring) — more can
    // be added once verified the same way.
    urls: [
      "https://apna.co/jobs/software-engineer-jobs",
      "https://apna.co/jobs/java-developer-jobs",
    ],
    hostPrefix: "https://apna.co/",
    injectFile: "content/apna.js",
  },
};

// Default, broad-but-still-on-topic title fragments — used only when the
// user hasn't set their own target keywords in Settings. Short enough that
// LinkedIn's search matches title variants a strict "Software Engineer"-only
// phrase would miss (Software Developer, SDE, Java Full Stack Developer,
// etc.), while still staying in the right role family. f_E (Internship/Entry/
// Associate) and f_JT (Full-time/Internship) do the real precision work at
// the facet level, so the keyword itself can afford to cast a wider net.
const DEFAULT_LINKEDIN_KEYWORD_QUERIES = [
  "Software Engineer",
  "Software Developer",
  "Full Stack Developer",
  "Full Stack Engineer",
  "Backend Developer",
  "Backend Engineer",
  "Java Developer",
  "Java Full Stack",
  "SDE",
  "Application Developer",
];

// geoId=102713980 (India) is only used as the fallback when the user hasn't
// set a location in their profile — LinkedIn also accepts a free-text
// `location=` param, which resolves best-effort for any other place.
const DEFAULT_GEO_ID = "102713980";

function buildLinkedinKeywordUrl(keyword, location) {
  const encoded = encodeURIComponent(keyword);
  const geoParam = location ? `location=${encodeURIComponent(location)}` : `geoId=${DEFAULT_GEO_ID}`;
  return `https://www.linkedin.com/jobs/search/?keywords=${encoded}&f_TPR=r86400&f_E=1%2C2%2C3&f_JT=F%2CI&${geoParam}&sortBy=DD`;
}

SCRAPE_SOURCES.linkedin.urls = DEFAULT_LINKEDIN_KEYWORD_QUERIES.map((k) => buildLinkedinKeywordUrl(k, null));

// Same rationale as DEFAULT_LINKEDIN_KEYWORD_QUERIES — short/broad titles
// instead of one long combined query, used only without a user profile.
const DEFAULT_INDEED_KEYWORD_QUERIES = [
  "software engineer",
  "software developer",
  "full stack developer",
  "backend developer",
  "java developer",
  "sde",
];

function buildIndeedKeywordUrl(keyword, location) {
  const encoded = encodeURIComponent(keyword);
  const l = encodeURIComponent(location || "India");
  return `https://in.indeed.com/jobs?q=${encoded}&l=${l}&fromage=1&explvl=entry_level&jt=fulltime&sort=date`;
}

SCRAPE_SOURCES.indeed.urls = DEFAULT_INDEED_KEYWORD_QUERIES.map((k) => buildIndeedKeywordUrl(k, null));

// Only two Apna category slugs are confirmed to actually scope results
// server-side (most guessed slugs silently fall back to the entire
// unfiltered feed instead of erroring — see content/apna.js). Best-effort
// pick between them from the user's own target keywords; more slugs can be
// added here once verified live the same way.
const APNA_CATEGORY_SLUGS = {
  java: "https://apna.co/jobs/java-developer-jobs",
  default: "https://apna.co/jobs/software-engineer-jobs",
};

function buildApnaUrls(targetKeywords) {
  const lower = (targetKeywords || []).map((k) => k.toLowerCase());
  const urls = [APNA_CATEGORY_SLUGS.default];
  if (lower.some((k) => k.includes("java"))) urls.push(APNA_CATEGORY_SLUGS.java);
  return urls;
}

// Fetches the logged-in user's job-matching profile (skills, target
// keywords, experience, location) so search URLs and in-page keyword/
// experience filters adapt to whoever is actually using the extension
// instead of one hardcoded resume. Falls back to nulls/empty on any failure
// so scraping still runs with the original defaults.
async function getUserProfile() {
  try {
    const res = await fetchFromBackend("/api/account/profile");
    if (!res || !res.ok) return { skills: [], targetKeywords: [], experienceYears: null, location: "" };
    const data = await res.json().catch(() => null);
    if (!data) return { skills: [], targetKeywords: [], experienceYears: null, location: "" };
    return {
      skills: Array.isArray(data.skills) ? data.skills : [],
      targetKeywords: Array.isArray(data.target_keywords) ? data.target_keywords : [],
      experienceYears: Number.isFinite(data.experience_years) ? data.experience_years : null,
      location: data.location || "",
    };
  } catch {
    return { skills: [], targetKeywords: [], experienceYears: null, location: "" };
  }
}

// NEW: Targeted Company Search
function normalizeCompanyQuery(value) {
  const cleaned = String(value || "").replace(/\s+/g, " ").trim();
  return cleaned.length ? cleaned.slice(0, 80) : "";
}

// NEW: Targeted Company Search
function toKebabCase(value) {
  return normalizeCompanyQuery(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

// NEW: Targeted Company Search
function buildCompanySearchUrl(source, company, location) {
  const encoded = encodeURIComponent(company);
  if (source === "linkedin") {
    // Same junior-only (f_E) + past-24h filters for targeted company search.
    const geoParam = location ? `location=${encodeURIComponent(location)}` : `geoId=${DEFAULT_GEO_ID}`;
    return `https://www.linkedin.com/jobs/search/?keywords=${encoded}&f_TPR=r86400&f_E=1%2C2%2C3&${geoParam}&sortBy=DD`;
  }
  if (source === "naukri") {
    const slug = toKebabCase(company) || "jobs";
    return `https://www.naukri.com/${slug}-jobs?k=${encoded}`;
  }
  if (source === "instahyre") {
    return `https://www.instahyre.com/jobs/?search=${encoded}`;
  }
  if (source === "hiringcafe") {
    // Same junior + tech-department filter, keyed to the company as the search term.
    const state = JSON.stringify({
      searchQuery: company,
      dateFetchedPastNDays: 2,
      departments: ["Software Development", "Engineering", "Information Technology", "Data and Analytics"],
      roleYoeRange: [0, 1],
      sortBy: "date",
    });
    return `https://hiring.cafe/?searchState=${encodeURIComponent(state)}`;
  }
  if (source === "indeed") {
    return buildIndeedKeywordUrl(company, location);
  }
  // Apna has no keyword search that reliably scopes results (confirmed via
  // testing — most guessed URL/query patterns silently fall back to the
  // entire unfiltered feed), so there's no reliable way to target a specific
  // company there. Omitted from company search.
  return null;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message.type === "JOBS_SCRAPED") {
    hasActiveSession()
      .then((active) => {
        if (!active) return sendResponse({ ok: false, error: "Session inactive" });
        return postToBackend("/api/jobs/batch", message.payload)
          .then(data => sendResponse({ ok: true, result: data }))
          .catch(err => sendResponse({ ok: false, error: err.message }));
      })
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true; // async
  }

  if (message.type === "PEOPLE_SCRAPED") {
    hasActiveSession()
      .then((active) => {
        if (!active) return sendResponse({ ok: false, error: "Session inactive" });
        return postToBackend("/api/leads/batch", message.payload)
          .then(data => sendResponse({ ok: true, result: data }))
          .catch(err => sendResponse({ ok: false, error: err.message }));
      })
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === "TOKEN_SYNC") {
    const { token, email } = message;
    syncAuthSession(token, email)
      .then(() => sendResponse({ ok: true }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === "TRIGGER_CONNECT") {
    chrome.storage.local.set({ connect_running: message.running });
    sendResponse({ ok: true });
  }

  if (message.type === "TRIGGER_CONNECT_NOW") {
    // Dashboard clicked Start Queue / Retry — kick the loop immediately instead
    // of waiting for the 30s alarm.
    hasActiveSession()
      .then(async (active) => {
        if (!active) return sendResponse({ ok: false, error: "Session inactive" });
        await syncRunState();
        if (!_connectLoopRunning) {
          _connectLoopRunning = true;
          runConnectLoop().finally(() => { _connectLoopRunning = false; });
        }
        sendResponse({ ok: true });
      })
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true; // async
  }

  if (message.type === "FIND_LEADS") {
    const { company, job_id } = message.payload;
    hasActiveSession()
      .then((active) => {
        if (!active) return sendResponse({ ok: false, error: "Session inactive" });
        return openLinkedInPeopleSearch(company, job_id)
          .then(() => sendResponse({ ok: true }))
          .catch(err => sendResponse({ ok: false, error: err.message }));
      })
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === "GET_DAILY_STATS") {
    chrome.storage.local.get(["connections_today", "last_reset_date", "connect_daily_limit"], async (data) => {
      const today = new Date().toDateString();
      const daily_limit = sanitizeDailyLimit(data.connect_daily_limit);
      if (data.last_reset_date !== today) {
        chrome.storage.local.set({ connections_today: 0, last_reset_date: today });
        if (data.connect_daily_limit == null) {
          await chrome.storage.local.set({ connect_daily_limit: daily_limit });
        }
        sendResponse({ connections_today: 0, daily_limit });
      } else {
        if (data.connect_daily_limit == null) {
          await chrome.storage.local.set({ connect_daily_limit: daily_limit });
        }
        sendResponse({ connections_today: data.connections_today || 0, daily_limit });
      }
    });
    return true;
  }

  if (message.type === "SET_DAILY_LIMIT") {
    const nextLimit = sanitizeDailyLimit(message?.limit);
    chrome.storage.local.set({ connect_daily_limit: nextLimit }, async () => {
      await persistDailyLimitToBackend(nextLimit);
      sendResponse({ ok: true, daily_limit: nextLimit });
    });
    return true;
  }

  if (message.type === "TRIGGER_SCRAPE_NOW") {
    hasActiveSession()
      .then((active) => {
        if (!active) return sendResponse({ ok: false, error: "Session inactive" });
        processPendingScrapeTasks().catch(() => {});
        sendResponse({ ok: true });
      })
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }
});

// Alarm fires every 30s as a heartbeat — kicks off the loop if not already running
let _connectLoopRunning = false;

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== "connect_tick") return;

  if (!(await hasActiveSession())) {
    await deactivateSession();
    return;
  }

  await syncRunState();
  await processPendingFindLeads();
  await processPendingScrapeTasks();

  if (!_connectLoopRunning) {
    _connectLoopRunning = true;
    runConnectLoop().finally(() => { _connectLoopRunning = false; });
  }
});

// Runs one LinkedIn connect attempt; returns "done", "no_item", "stopped", "limit_hit", or "captcha"
async function processOneConnection() {
  if (!(await hasActiveSession())) return "stopped";
  const connections_today = await ensureDailyReset();
  const { connect_running } = await chrome.storage.local.get("connect_running");
  const daily_limit = await getDailyLimit();

  if (!connect_running) return "stopped";
  if ((connections_today || 0) >= daily_limit) {
    chrome.storage.local.set({ connect_running: false });
    await postToBackend("/api/queue/stop", {}).catch(() => {});
    return "limit_hit";
  }

  const res = await fetchFromBackend("/api/queue/next");
  if (!res || !res.ok) return "no_item";
  const person = await res.json().catch(() => null);
  if (!person || !person.profile_url) return "no_item";

  // A fresh, disposable tab per connection -- NOT a reused one. Reusing one
  // tab and rapidly re-navigating it between many different profiles back to
  // back isn't how a real person browses, and confirmed reports show LinkedIn's
  // own frontend can retain stale "who am I inviting" state across that exact
  // pattern: the tab visibly displays the correct profile, yet the invite that
  // goes out is still for someone else. A brand-new tab per attempt, closed
  // right after, removes any possibility of that carrying over regardless of
  // the precise mechanism on LinkedIn's side.
  const targetTab = await chrome.tabs.create({ url: person.profile_url, active: false });

  try {
    await waitForTabLoad(targetTab.id);
    await new Promise(r => setTimeout(r, 1200));

    if (!(await hasActiveSession())) return "stopped";

    // Confirm the tab is actually showing the profile we just created it with.
    const targetPath = person.profile_url.replace(/^https?:\/\/[^/]+/, "").split("?")[0].replace(/\/$/, "");
    const checkTab = await chrome.tabs.get(targetTab.id).catch(() => null);
    const currentPath = checkTab?.url ? new URL(checkTab.url).pathname.replace(/\/$/, "") : "";
    if (targetPath && !currentPath.startsWith(targetPath)) {
      console.warn(`[bg] Tab drifted before DO_CONNECT: expected ${targetPath}, tab is on ${currentPath || "(unknown)"}`);
      await postToBackend("/api/queue/result", { queue_id: person.id, status: "failed", error_msg: "tab_url_mismatch" }).catch(() => {});
      return "done";
    }

    const response = await sendMessageToTabWithInjection(targetTab.id, {
      type: "DO_CONNECT",
      payload: { profile_url: person.profile_url, queue_id: person.id }
    }, 'content/linkedin_connect.js');

    if (!response) {
      console.warn('[bg] DO_CONNECT failed: content script unavailable even after inject');
      await postToBackend("/api/queue/result", { queue_id: person.id, status: "failed", error_msg: "content_script_unavailable" }).catch(() => {});
      return "done";
    }

    const status = response?.status || "failed";
    console.log(`[bg] DO_CONNECT result: ${status}`, response?.error || "");
    await postToBackend("/api/queue/result", { queue_id: person.id, status, error_msg: response?.error || null }).catch(() => {});

    if (status === "sent") {
      const d = await chrome.storage.local.get("connections_today");
      await chrome.storage.local.set({ connections_today: (d.connections_today || 0) + 1 });
    }

    if (response?.error === "captcha_checkpoint") {
      await chrome.storage.local.set({ connect_running: false });
      await postToBackend("/api/queue/stop", {}).catch(() => {});
      console.warn("[bg] Captcha/checkpoint detected — queue paused");
      return "captcha";
    }
  } catch (err) {
    console.error('[bg] DO_CONNECT unexpected error:', err?.message || err);
  } finally {
    chrome.tabs.remove(targetTab.id).catch(() => {});
  }

  return "done";
}

// Continuous loop: process connections with 5s between each one.
// Storage pings keep the service worker alive during the delay.
async function runConnectLoop() {
  while (true) {
    const result = await processOneConnection();
    if (result !== "done") break;
    await keepAliveDelay(5000);
  }
}

function keepAliveDelay(ms) {
  return new Promise(resolve => {
    let elapsed = 0;
    const tick = setInterval(() => {
      elapsed += 1000;
      chrome.storage.local.get("connect_running"); // prevents SW termination
      if (elapsed >= ms) { clearInterval(tick); resolve(); }
    }, 1000);
  });
}

// Poll backend for pending find-leads requests (called every 30s from alarm)
async function processPendingFindLeads() {
  try {
    if (!(await hasActiveSession())) return;
    const res = await fetchFromBackend("/api/find-leads/pending");
    if (!res || !res.ok) return;
    const request = await res.json().catch(() => null);
    // company is the only hard requirement now — job_id is '' for a direct
    // "find leads by company" request (no job attached).
    if (!request || !request.company) return;

    const desiredCount = Number.isFinite(request.requested_count) && request.requested_count > 0
      ? request.requested_count
      : 15;

    console.log(`[bg] Processing find-leads for ${request.job_id ? `job ${request.job_id}` : "company"} (${request.company}), want ${desiredCount}`);
    try {
      const { profiles } = await openLinkedInPeopleSearch(request.company, request.job_id, desiredCount);
      await patchToBackend(`/api/find-leads/${request.id}/done`, { status: "done", found_count: profiles.length }).catch(() => {});
    } catch (err) {
      console.error("[bg] Find leads failed:", err.message);
      await patchToBackend(`/api/find-leads/${request.id}/done`, { status: "failed" }).catch(() => {});
    }
  } catch (err) {
    console.error("[bg] processPendingFindLeads error:", err.message);
  }
}

async function processPendingScrapeTasks() {
  try {
    if (!(await hasActiveSession())) return;
    const res = await fetchFromBackend("/api/scrape/pending");
    if (!res || !res.ok) return;
    const task = await res.json().catch(() => null);
    if (!task || !task.id || !task.source) return;

    const result = await runScrapeTask(task);
    await postToBackend(`/api/scrape/${task.id}/result`, result).catch(() => {});
  } catch (err) {
    // Swallow; next alarm tick will retry processing.
  }
}

async function runScrapeTask(task) {
  if (!(await hasActiveSession())) {
    return { status: "failed", message: "Session inactive" };
  }
  const source = String(task.source || "").toLowerCase();
  const cfg = SCRAPE_SOURCES[source];
  if (!cfg) return { status: "failed", message: `Unknown source: ${source}` };

  // This user's own profile — drives which search URLs we build below AND is
  // handed to the content scripts (via window.__jhProfile) for in-page
  // keyword/experience filtering, instead of one hardcoded resume/location.
  const profile = await getUserProfile();

  // NEW: Targeted Company Search
  const companyQuery = normalizeCompanyQuery(task.company);
  const companyUrl = companyQuery ? buildCompanySearchUrl(source, companyQuery, profile.location) : null;

  // linkedin/indeed run several separate keyword searches back-to-back
  // instead of one URL -- a single combined boolean-OR query returned
  // noticeably fewer results than each search run on its own. Keywords come
  // from the user's own target_keywords/skills when set, else the defaults.
  const userKeywords = [...profile.targetKeywords, ...profile.skills].filter(Boolean);
  let sourceUrls = cfg.urls && cfg.urls.length ? cfg.urls : [cfg.url];
  if (!companyUrl && userKeywords.length) {
    if (source === "linkedin") sourceUrls = userKeywords.map((k) => buildLinkedinKeywordUrl(k, profile.location));
    else if (source === "indeed") sourceUrls = userKeywords.map((k) => buildIndeedKeywordUrl(k, profile.location));
    else if (source === "apna") sourceUrls = buildApnaUrls(userKeywords);
  } else if (!companyUrl && profile.location) {
    if (source === "linkedin") sourceUrls = DEFAULT_LINKEDIN_KEYWORD_QUERIES.map((k) => buildLinkedinKeywordUrl(k, profile.location));
    else if (source === "indeed") sourceUrls = DEFAULT_INDEED_KEYWORD_QUERIES.map((k) => buildIndeedKeywordUrl(k, profile.location));
  }

  // Targeted company search always overrides with its own single URL.
  const targetUrls = companyUrl ? [companyUrl] : sourceUrls;
  const iterating = targetUrls.length > 1;

  const targetTab = await getOrCreateWorkerTab(`scrape_${source}`, targetUrls[0]);

  for (let i = 0; i < targetUrls.length; i++) {
    if (i > 0) {
      await chrome.tabs.update(targetTab.id, { url: targetUrls[i] });
    }

    await waitForTabLoad(targetTab.id);
    await new Promise(r => setTimeout(r, 1800));

    if (!(await hasActiveSession())) {
      return { status: "failed", message: "Session inactive" };
    }

    // Only check for a login wall on the first search -- if we weren't
    // logged in, every later iteration would fail identically.
    if (i === 0) {
      const loginRequired = await detectLoginRequired(targetTab.id, source);
      if (loginRequired) {
        return { status: "login_required", message: `Please login on ${source} and click Scrape again.` };
      }
    }

    try {
      // Set window.__jhProfile in the tab's isolated world BEFORE job_match.js
      // runs, so its profile-aware thresholds see the real values from the
      // very first check (rather than racing an async storage/fetch read).
      await new Promise((resolve) => {
        chrome.scripting.executeScript(
          { target: { tabId: targetTab.id }, func: (p) => { window.__jhProfile = p; }, args: [profile] },
          () => resolve()
        );
      });
      await new Promise((resolve) => {
        chrome.scripting.executeScript(
          { target: { tabId: targetTab.id }, files: ["content/job_match.js", cfg.injectFile] },
          () => resolve()
        );
      });
    } catch (err) {
      return { status: "failed", message: `Failed to start scraper on ${source}` };
    }

    // Give the content script's own scroll/pagination loop time to run its
    // course before moving to the next search (or finishing) -- cutting it
    // off too soon would abandon a still-scrolling page mid-scrape.
    await new Promise(r => setTimeout(r, iterating ? 28000 : 2500));
  }

  const message = iterating
    ? `Scrape triggered for ${source} (${targetUrls.length} searches)`
    : `Scrape triggered for ${source}`;
  return { status: "completed", message };
}

async function detectLoginRequired(tabId, source) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: (src) => {
        const href = (window.location.href || "").toLowerCase();
        const title = (document.title || "").toLowerCase();
        const bodyText = (document.body?.innerText || "").toLowerCase().slice(0, 5000);

        const hasLoginForm = !!document.querySelector(
          'form[action*="login" i], input[type="password"], input[name*="password" i], input[name*="session_key" i]'
        );

        if (src === "linkedin") {
          if (/linkedin\.com\/(login|checkpoint|authwall|signup)/.test(href)) return true;
          if (title.includes("sign in") || title.includes("security verification")) return true;
        }
        if (src === "naukri") {
          if (/naukri\.com\/(nlogin|login|mnjuser\/home)/.test(href)) return true;
        }
        if (src === "cutshort") {
          if (/cutshort\.io\/(login|signin)/.test(href)) return true;
        }
        if (src === "instahyre") {
          if (/instahyre\.com\/(login|signin)/.test(href)) return true;
        }

        if (hasLoginForm && /sign in|log in|login/.test(bodyText)) return true;
        return false;
      },
      args: [source],
    });

    return !!results?.[0]?.result;
  } catch (err) {
    return false;
  }
}

async function ensureCoreAlarm() {
  try {
    const alarm = await chrome.alarms.get("connect_tick");
    if (!alarm) {
      chrome.alarms.create("connect_tick", { periodInMinutes: 0.5 });
    }
  } catch {}
}

// Create/repair alarm on install and startup
chrome.runtime.onInstalled.addListener(() => {
  ensureCoreAlarm().catch(() => {});
  deactivateSession().catch(() => {});
  initializeDailyLimit().catch(() => {});
});

chrome.runtime.onStartup.addListener(() => {
  ensureCoreAlarm().catch(() => {});
  deactivateSession().catch(() => {});
});

// Best-effort boot strap: make sure alarm exists.
ensureCoreAlarm().catch(() => {});

// ── Helpers ────────────────────────────────────────────────────────────────

async function hasActiveSession() {
  // The auth token (storage.sync) is the single source of truth and survives
  // extension reloads. We intentionally do NOT also require SESSION_ACTIVE_KEY —
  // that flag is cleared on every reload, which used to silently kill the queue
  // until the dashboard was refreshed. Signing out removes the token, which
  // correctly deactivates everything.
  const syncData = await chrome.storage.sync.get("jh_token");
  return Boolean(syncData.jh_token);
}

async function deactivateSession() {
  await chrome.storage.local.set({
    connect_running: false,
    [SESSION_ACTIVE_KEY]: false,
  });
}

async function invalidateSession() {
  await chrome.storage.sync.remove(["jh_token", "jh_email"]);
  await deactivateSession();
}

async function syncAuthSession(token, email) {
  if (token) {
    await chrome.storage.sync.set({ jh_token: token, jh_email: email || "" });
    await chrome.storage.local.set({ [SESSION_ACTIVE_KEY]: true });
    return;
  }
  await clearAuthSession();
}

async function clearAuthSession() {
  const { jh_token } = await chrome.storage.sync.get("jh_token");
  if (jh_token) {
    await cleanupBackendSession(jh_token).catch(() => {});
  }
  await invalidateSession();
}

async function cleanupBackendSession(token) {
  await postToBackendWithToken("/api/queue/stop", {}, token).catch(() => null);
  await postToBackendWithToken("/api/scrape/cancel", {}, token).catch(() => null);
  await postToBackendWithToken("/api/find-leads/cancel", {}, token).catch(() => null);
}

async function getAuthHeaders(includeContentType = true) {
  const data = await chrome.storage.sync.get("jh_token");
  const headers = {};
  if (includeContentType) headers["Content-Type"] = "application/json";
  if (data.jh_token) headers["Authorization"] = `Bearer ${data.jh_token}`;
  return headers;
}

async function postToBackendWithToken(path, data, token) {
  const headers = { "Content-Type": "application/json" };
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const res = await fetch(`${BACKEND}${path}`, {
    method: "POST",
    headers,
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error(`Backend error: ${res.status}`);
  return res.json();
}

async function postToBackend(path, data) {
  const headers = await getAuthHeaders();
  const res = await fetch(`${BACKEND}${path}`, {
    method: "POST",
    headers,
    body: JSON.stringify(data),
  });
  if (res.status === 401) {
    await invalidateSession();
    throw new Error("Session expired");
  }
  if (!res.ok) throw new Error(`Backend error: ${res.status}`);
  return res.json();
}

async function patchToBackend(path, data) {
  const headers = await getAuthHeaders();
  const res = await fetch(`${BACKEND}${path}`, {
    method: "PATCH",
    headers,
    body: JSON.stringify(data),
  });
  if (res.status === 401) {
    await invalidateSession();
    throw new Error("Session expired");
  }
  if (!res.ok) throw new Error(`Backend error: ${res.status}`);
  return res.json();
}

async function fetchFromBackend(path) {
  const headers = await getAuthHeaders();
  const res = await fetch(`${BACKEND}${path}`, { headers }).catch(() => null);
  if (res?.status === 401) {
    await invalidateSession();
    return null;
  }
  return res;
}

// Sync backend run-state → chrome.storage so alarm reads the right value
async function syncRunState() {
  try {
    const res = await fetchFromBackend("/api/queue/run-state");
    if (!res?.ok) return;
    const data = await res.json().catch(() => null);
    if (data && typeof data.running === "boolean") {
      await chrome.storage.local.set({ connect_running: data.running });
    }
  } catch {}
  await syncDailyLimitFromBackend();
  await syncConnectionsTodayFromBackend();
}

// The backend's daily_stats is the source of truth for today's sent count. Mirror
// it locally so the limit check can't drift (and so resetting it server-side
// actually clears the local cap).
async function syncConnectionsTodayFromBackend() {
  try {
    const res = await fetchFromBackend("/api/stats/today");
    if (!res?.ok) return;
    const data = await res.json().catch(() => null);
    if (!data) return;
    const sent = parseInt(data.connections_sent || 0, 10);
    if (Number.isFinite(sent)) {
      await chrome.storage.local.set({
        connections_today: sent,
        last_reset_date: new Date().toDateString(),
      });
    }
  } catch {}
}

async function ensureDailyReset() {
  const today = new Date().toDateString();
  const data = await chrome.storage.local.get(["connections_today", "last_reset_date"]);
  if (data.last_reset_date !== today) {
    await chrome.storage.local.set({ connections_today: 0, last_reset_date: today });
    return 0;
  }
  return data.connections_today || 0;
}

function sanitizeDailyLimit(value) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) return DEFAULT_DAILY_LIMIT;
  return Math.min(MAX_DAILY_LIMIT, Math.max(MIN_DAILY_LIMIT, parsed));
}

async function initializeDailyLimit() {
  const data = await chrome.storage.local.get("connect_daily_limit");
  if (data.connect_daily_limit == null) {
    await chrome.storage.local.set({ connect_daily_limit: DEFAULT_DAILY_LIMIT });
    return DEFAULT_DAILY_LIMIT;
  }
  const sanitized = sanitizeDailyLimit(data.connect_daily_limit);
  if (sanitized !== data.connect_daily_limit) {
    await chrome.storage.local.set({ connect_daily_limit: sanitized });
  }
  return sanitized;
}

async function getDailyLimit() {
  const data = await chrome.storage.local.get("connect_daily_limit");
  if (data.connect_daily_limit == null) {
    return initializeDailyLimit();
  }
  const sanitized = sanitizeDailyLimit(data.connect_daily_limit);
  if (sanitized !== data.connect_daily_limit) {
    await chrome.storage.local.set({ connect_daily_limit: sanitized });
  }
  return sanitized;
}

async function syncDailyLimitFromBackend() {
  try {
    const res = await fetchFromBackend("/api/stats/daily-limit");
    if (!res?.ok) return;
    const data = await res.json().catch(() => null);
    if (!data) return;
    const backendLimit = sanitizeDailyLimit(data.daily_limit);
    await chrome.storage.local.set({ connect_daily_limit: backendLimit });
  } catch {}
}

async function persistDailyLimitToBackend(limit) {
  try {
    await postToBackend("/api/stats/daily-limit", { daily_limit: sanitizeDailyLimit(limit) }).catch(() => null);
  } catch {}
}

// Send a message to a tab; if the content script is not present, try injecting it and retry once.
async function sendMessageToTabWithInjection(tabId, message, injectFile) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, async (response) => {
      if (!chrome.runtime.lastError) return resolve(response);
      console.warn('[bg] sendMessage error:', chrome.runtime.lastError.message, '— attempting to inject', injectFile);

      // Try to inject the requested content script file into the tab, then retry once
      try {
        chrome.scripting.executeScript({ target: { tabId }, files: [injectFile] }, async () => {
          // small delay to let the script initialize
          await new Promise(r => setTimeout(r, 500));
          chrome.tabs.sendMessage(tabId, message, (resp2) => {
            if (chrome.runtime.lastError) {
              console.warn('[bg] sendMessage after inject failed:', chrome.runtime.lastError.message);
              return resolve(null);
            }
            resolve(resp2);
          });
        });
      } catch (err) {
        console.error('[bg] scripting.executeScript failed:', err?.message || err);
        return resolve(null);
      }
    });
  });
}

// Resolves when a tab reaches status=complete (or after 15s timeout)
function waitForTabLoad(tabId) {
  return new Promise(resolve => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      chrome.tabs.onUpdated.removeListener(listener);
      clearTimeout(t);
      resolve();
    };
    const t = setTimeout(finish, 15000);
    function listener(id, info) {
      if (id === tabId && info.status === "complete") finish();
    }
    chrome.tabs.onUpdated.addListener(listener);
    // Already loaded?
    chrome.tabs.get(tabId, tab => { if (tab?.status === "complete") finish(); });
  });
}

async function fetchJob(job_id) {
  if (!job_id) return null;
  const res = await fetchFromBackend(`/api/jobs/${job_id}`);
  if (!res || !res.ok) return null;
  return res.json().catch(() => null);
}

function normalizeText(value) {
  return (value || "").replace(/\s+/g, " ").trim();
}

function buildRoleTokens(title) {
  const lower = normalizeText(title).toLowerCase();
  const tokens = new Set();

  if (/(front[-\s]?end|frontend|ui|react)/.test(lower)) {
    ["frontend engineer", "frontend developer", "react developer"].forEach(t => tokens.add(t));
  }
  if (/(back[-\s]?end|backend|api|server|node)/.test(lower)) {
    ["backend engineer", "backend developer", "api engineer", "node.js developer"].forEach(t => tokens.add(t));
  }
  if (/(full\s*stack|fullstack)/.test(lower)) {
    ["full stack engineer", "full stack developer"].forEach(t => tokens.add(t));
  }
  if (/(data|machine learning|ml|ai)/.test(lower)) {
    ["data engineer", "machine learning engineer", "ai engineer"].forEach(t => tokens.add(t));
  }
  if (/(devops|sre)/.test(lower)) {
    ["devops engineer", "site reliability engineer"].forEach(t => tokens.add(t));
  }
  if (/(mobile|android|ios)/.test(lower)) {
    ["mobile engineer", "android engineer", "ios engineer"].forEach(t => tokens.add(t));
  }
  if (/(blockchain|web3|solidity)/.test(lower)) {
    ["blockchain engineer", "web3 engineer", "solidity developer"].forEach(t => tokens.add(t));
  }

  if (tokens.size === 0) {
    ["software engineer", "software developer"].forEach(t => tokens.add(t));
  }

  return Array.from(tokens).slice(0, 8);
}

function buildLeadQueries(company, jobTitle) {
  const cleanCompany = normalizeText(company);
  const roleTokens = buildRoleTokens(jobTitle);
  const roleQuery = roleTokens.map(t => `"${t}"`).join(" OR ");

  const queries = [
    `${cleanCompany} ("talent acquisition" OR recruiter OR "human resources" OR HR OR "people operations")`,
    `${cleanCompany} ("engineering manager" OR "hiring manager" OR "tech lead" OR "lead engineer" OR "vp engineering" OR CTO)`,
    `${cleanCompany} (${roleQuery})`,
  ];

  return queries.filter(q => q.trim().length > 0);
}

async function runPeopleSearch(query, job_id, company) {
  if (!(await hasActiveSession())) return [];
  const url = `https://www.linkedin.com/search/results/people/?keywords=${encodeURIComponent(query)}&origin=GLOBAL_SEARCH_HEADER`;
  const tab = await chrome.tabs.create({ url, active: false });

  return new Promise((resolve) => {
    let settled = false;
    const cleanup = () => {
      if (settled) return;
      settled = true;
      chrome.tabs.onUpdated.removeListener(listener);
      clearTimeout(timeout);
    };

    const timeout = setTimeout(() => {
      cleanup();
      if (tab?.id) chrome.tabs.remove(tab.id);
      resolve([]);
    }, 18000);

    function listener(tabId, info) {
      if (tabId !== tab.id || info.status !== "complete") return;
      cleanup();

      setTimeout(async () => {
        if (!(await hasActiveSession())) {
          chrome.tabs.remove(tab.id);
          return resolve([]);
        }

        const response = await sendMessageToTabWithInjection(tab.id, {
          type: "SCRAPE_PEOPLE",
          payload: { company, job_id }
        }, 'content/linkedin_people.js');

        if (!response) {
          chrome.tabs.remove(tab.id);
          return resolve([]);
        }

        chrome.tabs.remove(tab.id);
        resolve(response?.profiles || []);
      }, 2200);
    }

    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function openLinkedInPeopleSearch(company, job_id, desiredCount = 15) {
  if (!(await hasActiveSession())) return { profiles: [] };
  // fetchJob('') / fetchJob(undefined) already resolves to null — a direct
  // "find leads by company" request has no job_id, buildLeadQueries falls
  // back to a generic "software engineer/developer" role query in that case.
  const job = await fetchJob(job_id);
  const jobTitle = job?.title || "";
  const cleanCompany = normalizeText(company || job?.company || "");
  const queries = buildLeadQueries(cleanCompany, jobTitle);

  const collected = [];
  const seen = new Set();

  for (const q of queries) {
    if (!(await hasActiveSession())) break;
    console.log("[bg] Lead search query:", q);
    const profiles = await runPeopleSearch(q, job_id, cleanCompany);
    profiles.forEach(p => {
      if (!p?.profile_url || seen.has(p.profile_url)) return;
      seen.add(p.profile_url);
      collected.push(p);
    });
    if (collected.length >= desiredCount) break;
  }

  // A query can return more than the remaining headroom in one batch — trim
  // to exactly what was asked for rather than over-delivering.
  const finalProfiles = collected.slice(0, desiredCount);

  if (finalProfiles.length > 0) {
    try {
      await postToBackend("/api/leads/batch", {
        profiles: finalProfiles,
        job_id,
        company: cleanCompany,
      });
      console.log(`[bg] Sent ${finalProfiles.length} profiles to backend`);
    } catch (err) {
      console.error("[bg] Failed to post leads:", err.message);
    }
  }

  return { profiles: finalProfiles };
}
